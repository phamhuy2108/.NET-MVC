namespace DoAn1_DoAn.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial4 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.LichSuHeThongs",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        ngay = c.DateTime(nullable: false),
                        doituong = c.String(),
                        thaotac = c.String(),
                    })
                .PrimaryKey(t => t.id);
            
            CreateTable(
                "dbo.LichSuMuaSaches",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        ngay = c.DateTime(nullable: false),
                        doituong = c.String(),
                        thaotac = c.String(),
                        masach = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.id);
            
            CreateTable(
                "dbo.SoLuongNguoiDangNhaps",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        thang = c.Int(nullable: false),
                        soluongnguoi = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.id);
            
            CreateTable(
                "dbo.SoLuongSachDuocBanRas",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        thang = c.Int(nullable: false),
                        soluongban = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.SoLuongSachDuocBanRas");
            DropTable("dbo.SoLuongNguoiDangNhaps");
            DropTable("dbo.LichSuMuaSaches");
            DropTable("dbo.LichSuHeThongs");
        }
    }
}
