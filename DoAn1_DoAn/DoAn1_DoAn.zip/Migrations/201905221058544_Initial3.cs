namespace DoAn1_DoAn.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial3 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Saches", "gia", c => c.Double(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Saches", "gia");
        }
    }
}
