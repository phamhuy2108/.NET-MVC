namespace DoAn1_DoAn.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial2 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Saches", "hinh", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.Saches", "hinh");
        }
    }
}
