namespace DoAn1_DoAn.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Intial1 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.NhaCungCaps", "isdeleted", c => c.Boolean(nullable: false));
            AddColumn("dbo.NhaXuatBans", "isdeleted", c => c.Boolean(nullable: false));
            AddColumn("dbo.TacGias", "isdeleted", c => c.Boolean(nullable: false));
            AddColumn("dbo.TheLoais", "isdeleted", c => c.Boolean(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.TheLoais", "isdeleted");
            DropColumn("dbo.TacGias", "isdeleted");
            DropColumn("dbo.NhaXuatBans", "isdeleted");
            DropColumn("dbo.NhaCungCaps", "isdeleted");
        }
    }
}
