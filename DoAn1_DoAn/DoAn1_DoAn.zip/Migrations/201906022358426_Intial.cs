namespace DoAn1_DoAn.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Intial : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.LichSuMuaSaches", "soluong", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.LichSuMuaSaches", "soluong");
        }
    }
}
