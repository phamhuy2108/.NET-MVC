namespace DoAn1_DoAn.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial1 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Saches", "NhaCungCap_mancc", "dbo.NhaCungCaps");
            DropForeignKey("dbo.Saches", "NhaXuatBan_manxb", "dbo.NhaXuatBans");
            DropIndex("dbo.Saches", new[] { "NhaCungCap_mancc" });
            DropIndex("dbo.Saches", new[] { "NhaXuatBan_manxb" });
            DropColumn("dbo.Saches", "mancc");
            DropColumn("dbo.Saches", "manxb");
            RenameColumn(table: "dbo.Saches", name: "NhaCungCap_mancc", newName: "mancc");
            RenameColumn(table: "dbo.Saches", name: "NhaXuatBan_manxb", newName: "manxb");
            DropPrimaryKey("dbo.NhaCungCaps");
            DropPrimaryKey("dbo.NhaXuatBans");
            AlterColumn("dbo.Saches", "mancc", c => c.Int(nullable: false));
            AlterColumn("dbo.Saches", "manxb", c => c.Int(nullable: false));
            AlterColumn("dbo.NhaCungCaps", "mancc", c => c.Int(nullable: false, identity: true));
            AlterColumn("dbo.NhaXuatBans", "manxb", c => c.Int(nullable: false, identity: true));
            AddPrimaryKey("dbo.NhaCungCaps", "mancc");
            AddPrimaryKey("dbo.NhaXuatBans", "manxb");
            CreateIndex("dbo.Saches", "mancc");
            CreateIndex("dbo.Saches", "manxb");
            AddForeignKey("dbo.Saches", "mancc", "dbo.NhaCungCaps", "mancc", cascadeDelete: true);
            AddForeignKey("dbo.Saches", "manxb", "dbo.NhaXuatBans", "manxb", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Saches", "manxb", "dbo.NhaXuatBans");
            DropForeignKey("dbo.Saches", "mancc", "dbo.NhaCungCaps");
            DropIndex("dbo.Saches", new[] { "manxb" });
            DropIndex("dbo.Saches", new[] { "mancc" });
            DropPrimaryKey("dbo.NhaXuatBans");
            DropPrimaryKey("dbo.NhaCungCaps");
            AlterColumn("dbo.NhaXuatBans", "manxb", c => c.String(nullable: false, maxLength: 128));
            AlterColumn("dbo.NhaCungCaps", "mancc", c => c.String(nullable: false, maxLength: 128));
            AlterColumn("dbo.Saches", "manxb", c => c.String(maxLength: 128));
            AlterColumn("dbo.Saches", "mancc", c => c.String(maxLength: 128));
            AddPrimaryKey("dbo.NhaXuatBans", "manxb");
            AddPrimaryKey("dbo.NhaCungCaps", "mancc");
            RenameColumn(table: "dbo.Saches", name: "manxb", newName: "NhaXuatBan_manxb");
            RenameColumn(table: "dbo.Saches", name: "mancc", newName: "NhaCungCap_mancc");
            AddColumn("dbo.Saches", "manxb", c => c.Int(nullable: false));
            AddColumn("dbo.Saches", "mancc", c => c.Int(nullable: false));
            CreateIndex("dbo.Saches", "NhaXuatBan_manxb");
            CreateIndex("dbo.Saches", "NhaCungCap_mancc");
            AddForeignKey("dbo.Saches", "NhaXuatBan_manxb", "dbo.NhaXuatBans", "manxb");
            AddForeignKey("dbo.Saches", "NhaCungCap_mancc", "dbo.NhaCungCaps", "mancc");
        }
    }
}
