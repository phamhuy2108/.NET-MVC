﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace DoAn1_DoAn.Models
{
    public class NhaXuatBan
    {
        [Key]
        public int manxb { get; set; }
        //[ForeignKey("Sach")]
        //public int masach { get; set; }
        public string tennxb { get; set; }
        public bool isdeleted { get; set; }
        public ICollection<Sach> DSS { get; set; }
        public static List<NhaXuatBan> ListNhaXuatBan()
        {
            List<NhaXuatBan> b = null;
            using (var db = new Context())
            {
                b = db.NhaXuatBan.ToList();
                db.Dispose();
            }
            return b;
        }
    }
}