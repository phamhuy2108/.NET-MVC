﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace DoAn1_DoAn.Models
{
    public class NhaCungCap
    {
        [Key]
        public int mancc { get; set; }
        //[ForeignKey("Sach")]
        //public int masach { get; set; }
        public string tenncc { get; set; }
        public bool isdeleted { get; set; }
        public ICollection<Sach> DSS { get; set; }
        public static List<NhaCungCap> ListNhaCungCap()
        {
            List<NhaCungCap> b = null;
            using (var db = new Context())
            {
                b = db.NhaCungCap.ToList();
                db.Dispose();
            }
            return b;
        }
    }  
}